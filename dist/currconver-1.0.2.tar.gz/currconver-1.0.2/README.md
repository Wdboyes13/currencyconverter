# Currency Converter using current stocks  
To use run `pip install currconver`  
To authorize with Open Exchange Rates run `python3 -m currconver AUTH`
For conversion run `python3 -m currconver CONV local_currency destination_currency amount_decimal`